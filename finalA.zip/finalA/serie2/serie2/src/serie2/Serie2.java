/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serie2;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class Serie2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nombre;
        String edad;
        
        System.out.println("ingrese su nombre");
        Scanner n = new Scanner(System.in);
        nombre = n.nextLine();  
                
        System.out.println("ingrese su edad");
        Scanner n1 = new Scanner(System.in);
        edad = n1.nextLine();  
        
                }
    
}
